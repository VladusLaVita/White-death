using UnityEngine;
using static ItemData;

public class PlayerCombat : MonoBehaviour
{
    [SerializeField] private Transform shootPoint;
    [SerializeField] private Inventory inventory;

    private float nextFireTime;

    void Update()
    {
        HandleShooting();
    }

    private void HandleShooting()
    {
        ItemData item = inventory.GetSelectedItem();

        if (item == null || item.itemType != ItemData.ItemType.Weapon)
        {
            return;
        }

        if (Input.GetMouseButton(0) && Time.time >= nextFireTime)
        {
            Shoot(item);
            nextFireTime = Time.time + item.fireRate;
        }
    }

    private void Shoot(ItemData weapon)
    {
        if (weapon.projectilePrefab == null)
        {
            Debug.LogWarning("No projectilePrefab on weapon: " + weapon.itemName);
            return;
        }
        Instantiate(weapon.projectilePrefab, shootPoint.position, shootPoint.rotation);
    }
}